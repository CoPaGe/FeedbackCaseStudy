def fun(n):
    t=[4,7,47,74,444,447,474,477,744,747,774,777]
    flag='NO'
    for x in t:
        if (n%x==0):
            flag='YES'
    
    return(flag)
