def fun(n):
    l=[]
    flag=0
    c=0
    for i in range(1,(n+1)):
        if(n%i==0):
            s=str(i)
            l.append(s)
    for j in range(0,len(l)):
        for k in range(0,len(l[j])):
            if(l[j][k]=='4' or l[j][k]=='7'):
                c=c+1
        if(c==len(l[j])):
            flag=1
            break
        c=0    
    if(flag==1):
        return 'YES'
    else:
        return 'NO'
