def fun(a):
    a = int(a)
 
    if a%4 == 0 or a%7 == 0 or a%47 == 0 or a%744 == 0 or a%447==0:
        return "YES"
    else:
        return "NO"