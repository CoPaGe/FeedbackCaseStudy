def fun(n):
    flag=0
    if n%4==0 or n%7==0:
        flag=0
    else:
        while n>0:
            if n%10==4 or n%10==7:
                flag=0
            else:
                flag=1
                break
            n=n/10
    if flag==0:
        return 'YES'
    else:
        return 'NO'