def fun(n):
    if(n%4)==0 or n%7 == 0 or n%47 == 0 or n%74 == 0:
        return "YES"
    else :
        return "NO"