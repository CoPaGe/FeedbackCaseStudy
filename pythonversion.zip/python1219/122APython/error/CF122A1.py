def fun(n):
    c=0
    if int(n)%4==0 or int(n)%7==0:
        return "YES"
    else:
        for x in range(len(n)):
            if n[x]=='4' or n[x]=='7':
                c+=1
        if c==len(n):
            return "YES"
        else:
            return "NO"