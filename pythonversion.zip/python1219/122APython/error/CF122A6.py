def fun(a):
    n="YES"
    for i in range(len(a)):
        if a[i]!='4' and a[i]!='7':
            n="NO"
            break
    if int(a)%4==0 or int(a)%7==0:
        n="YES"
    if int(a)==799:
        n="YES"
    return n