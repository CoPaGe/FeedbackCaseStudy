def fun(n):
    fact=[4,7,47,74,444,447,474,744,747,777]
    for i in fact:
        if n%i==0:
            return "YES"
    return "NO"