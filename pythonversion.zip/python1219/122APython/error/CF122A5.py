def fun(a):
    f = 0
    if(int(a)%4 == 0 or int(a)%7 == 0):
        return "YES"
    else:
        for i in a:
            if((i != "4") and (i != "7")):
                f = 1
                break
        if(f == 0):
            return "YES"
        else:
            return "NO"