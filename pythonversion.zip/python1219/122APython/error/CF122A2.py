def fun(x):
    list = [4,7,47,74,44,444,447,474,477,777,774,744]
    for l in list :
        if(x%l==0):
            return('YES')
        else:
            return('NO')