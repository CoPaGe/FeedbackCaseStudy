def fun(x):
    if(x%2==0):
        n=x//2
        return n
    else:
        n=x//2
        return n-x