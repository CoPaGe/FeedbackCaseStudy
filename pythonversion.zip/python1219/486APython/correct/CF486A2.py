def fun(n):
    c = 0
    if n%2 == 0:
        c = n/2
    else:
        c = (n-1)/2
        c = c-n 
    return c