def fun(n):
    if(n%2==0):
        return n/2
    else:
        pre = (n-1)/2
        return pre-n