def fun(n):
    if(-1**n)*n>=0:
        return n/2
    else:
        return -(n+1)/2