def fun(layer):
    feeling = ""
 
    for i in xrange(layer):
        if i > 0:
            feeling += " that "
        if i % 2 == 0:
            feeling += "I hate"
        else:
            feeling += "I Love" 
    
    feeling += " "+"it"
 
    return feeling