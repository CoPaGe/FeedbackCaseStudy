def fun(n):
    n-=1
    res = ""
    res+= "I hate it"
    for i in range(n):
        if i%2==0:
            res+= "that I love it"
        else:
            res+= "that I hate it"
    return res
