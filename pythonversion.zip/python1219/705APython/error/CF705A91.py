def fun(s):
    a = ""
 
    for i in range (s):
 
        if i % 2 == 0:
            a = a + "I hate it "
        else:
            a = a +	"I love it "
 
    return a