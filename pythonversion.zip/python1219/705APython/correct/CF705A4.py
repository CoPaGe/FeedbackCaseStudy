def fun(n):
    if(n==1):
        return "I hate it"
    else:
        st="I hate"
        for x in range(1,n):
            if(x%2==1):
                st=st+" that I love"
            else:
                st=st+" that I hate"
        st=st+" it"
        return st