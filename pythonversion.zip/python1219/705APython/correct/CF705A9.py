def fun(n):
    newS=''
    if n<2:
        print 'I hate it'
    else:
        for i in range(1,n+1):
            if i==n:
                if i%2==0:
                    newS=newS+' I love it'
                else:
                    newS=newS+' I hate it'
            elif i==1:
                newS=newS+'I hate that'
            else:
                if i%2==0:
                    newS=newS+' I love that'
                else:
                    newS=newS+' I hate that'
        return newS
