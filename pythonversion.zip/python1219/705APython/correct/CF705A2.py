def fun(n):
    line = "I hate it"
    i = 2
    while(i <= n):
        if(i % 2 == 0):
            line = line.replace("it", "that I love it")
            i+= 1
        else:
            line = line.replace("it", "that I hate it")
            i += 1
    return(line)