def fun(n):
    out = ''
    for i in xrange(n):
        if i % 2 == 0:
            out += 'I hate'
        else:
            out += 'I love'
        if i == n-1:
            out += ' it '
        else:
            out += ' that '
    return out