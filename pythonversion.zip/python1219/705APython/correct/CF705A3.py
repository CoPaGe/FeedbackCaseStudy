def fun(inp1):
    lster =["hate","love"]
    end ="it"
    that=" that"

    msg=""
    counter=0
    inCounter=0
    for i in range(0,inp1):
	
        if counter==0:
            msg+="I "+lster[counter]+" "
            counter=1
        else:
            msg+="I "+lster[counter]+" "
            counter=0
        inCounter+=1
        if inCounter!=inp1:
            msg+="that "
        if inCounter==inp1:
            msg+="it"
 
    return msg