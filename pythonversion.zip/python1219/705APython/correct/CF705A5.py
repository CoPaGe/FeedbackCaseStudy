def fun(x):
    a='that I hate '
    b='that I love '
    c='it'
    d='I hate '
    for y in xrange(x-1):
        if y%2==1:
            d=d+a
        else:
            d=d+b
    d=d+c
    return d