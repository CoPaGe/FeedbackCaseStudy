def fun(a):
    h=['h','e','l','l','o']
    m=0
    for i in range(len(a)):
        if m<5:
            if a[i]==h[m]:
                m+=1
    if m==5:
        return "YES"
    else:
        return "NO"