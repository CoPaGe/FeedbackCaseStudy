def fun(ent):
  a = "hello"
  index = 0
  for i in ent:
    if i == a[index]:
      index += 1
    if index == 5:
      return "YES"
  return "NO"