def fun(s):
    arr={}
    arr[0]='h'
    arr[1]='e'
    arr[2]='l'
    arr[3]='l'
    arr[4]='o'
    l=len(s)
    count=0
    x=0
    for i in range(5):
        for j in range(x,l):
            if arr[i]==s[j]:
                x=j+1
                count=count+1
                break
    if count==5:
        return 'YES'
    else:
        return 'NO'