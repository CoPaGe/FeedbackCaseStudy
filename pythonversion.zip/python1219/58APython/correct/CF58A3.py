def fun(message):
    hello = 'hello'
    index = 0
    i = 0
 
    while index < len(hello) and i < len(message):
        if message[i] == hello[index]:
            index += 1
 
        i += 1
 
    return 'YES' if index == len(hello) else 'NO'