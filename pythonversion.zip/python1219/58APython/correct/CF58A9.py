def fun(s):
    word = 'hello'
    i_word = 0
 
    for i in s:
        if (i == word[i_word]):
            i_word+=1
        if (i_word == 5):
            return "YES"
            
    if (i_word != 5):
        return "NO"