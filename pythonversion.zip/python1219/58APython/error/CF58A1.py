def fun(n):
    x=[]
    ans="YES"
 
    b=n.find("h")
    c=n[b+1:].find("e")
    c=c+b+1
    d=n[c+1:].find("l")
    d=d+c+1
 
    g=n[d+1:].find("l")
    g=g+d+1
 
    f=n[g+1:].find("o")
    f=f+g+1
 
    x=[b,c,d,g,f]
 
    for i in range(len(x)-1):
        if x[i]>x[i+1]:
            ans="NO"
    return ans