def fun(wordInput):
    word = "hello"
    for i in range(0, len(wordInput), 1):
		j = i
		k = 0
		letra_anterior = ""
		
		while(j < len(wordInput) - i):
			if(word[k] == wordInput[j] and letra_anterior != word[k]):
 
				if k == 2 and wordInput[j+1] == "l":
					k += 1
					j += 1
					
				letra_anterior = wordInput[j]
				
				k += 1
 
			j += 1
			
			if k > 4: break
 
		if k == 5:
			return 'YES'
	
    return 'NO'