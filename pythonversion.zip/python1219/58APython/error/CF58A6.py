def fun(word):
    hello = ""
    
    for i in range(len(word)):
        if word[i] == "h" and len(hello) == 0:
            hello = hello + word[i]
        if word[i] == "e" and len(hello) == 1:
            hello = hello + word[i]
        if word[i] == "l" and len(hello) == 3 and hello[len(hello) - 1] == "l":
            hello = hello + word[i]
        if word[i] == "l" and len(hello) == 2:
            hello = hello + word[i]
        if word[i] == "o" and len(hello) == 4:
            hello = hello + word[i]
 
    res = hello
 
    if "hello" in hello:
        res+= "YES"
    else:
        res+= "NO" 
    return res