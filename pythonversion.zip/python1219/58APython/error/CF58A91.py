def fun(s):
    a=s.find('h')
    b=s.find('e')
    c=s.find('l')
    d=s.find('l',(c+1))
    e=s.find('o')
 
    if((a<b) and (b<c) and (c<d) and (d<e)):
        return 'YES'
    else:
        return 'NO'