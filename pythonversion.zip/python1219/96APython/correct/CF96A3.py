def fun(input):
 
    count=0
    current=""
    result="NO"
    for char in input:
        if char == current:
            count +=1
            if count == 7:
                result ="YES"
                break
        else:
            count = 1
            current = char
    return result