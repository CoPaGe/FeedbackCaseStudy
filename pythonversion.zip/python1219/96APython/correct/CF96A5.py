def fun(k):
 
    q = "0000000"
    p = "1111111"

    if q in k or p in k:
        return "YES"
    else:
        return "NO"