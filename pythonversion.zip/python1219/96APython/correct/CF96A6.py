def fun(s):
 
    a="0"*7
    b="1"*7
    if a in s or b in s:
        return "YES"
    else:
        return"NO"