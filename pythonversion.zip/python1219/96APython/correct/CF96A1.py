def fun(s):
    count=1
    if(len(s)!=0 and s!=''):
        for i in range (len(s)-1):
            if(s[i+1]==s[i]):
                count+=1
                if(count==7):
                    break
            else:
                count=1
 
    if(count==7):
        return 'YES'
    else:
        return 'NO'