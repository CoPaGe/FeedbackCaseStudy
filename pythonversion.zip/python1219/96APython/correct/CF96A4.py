def fun(x):
 
 
    cont = 0
    cont1 = 0
    control = True
    for m in x:
        if  m == "0":
            cont += 1
            cont1 = 0
        else:
            cont = 0
            cont1 += 1
        if cont == 7 or cont1 == 7:
            break
 
    if cont >= 7 or cont1 >= 7:
        return "YES"
    else:
        return "NO"