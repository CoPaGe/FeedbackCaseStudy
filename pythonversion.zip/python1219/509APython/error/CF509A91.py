def fun(n):
    if n==1:
        return 1
    elif n==2:
        return 2
    elif n==3:
        return 6
    elif n==4:
        return 20
    elif n==5:
        return 70
    elif n==6:
        return 252
    elif n==7:
        return 924
    elif n==8:
        return 3432
    elif n==9:
        return 4719
    else:
        return 11940
 
		
		 

print(fun(5))