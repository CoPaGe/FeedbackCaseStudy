def fun(n):
    a=[[]]
    for i in range(0,n):
        a[0].append(1)
    res = ""
    res+= str(a)
    for i in range(1,n):
        a.append([1])
        for v in range(1,n):
            a[i].append(a[i][v-1]+a[i-1][v])
 
    res+= str(a)
    return res