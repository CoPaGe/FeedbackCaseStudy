def fun(a):
    b=a
    li=[]
    for aa in range(a):
        li.append(1)
 
    while (b>1):
        for i in range(1,a):
            li[i]=li[i]+li[i-1]
        b-=1
	
    return li[a-1]