def fun(n):
    m=[]
    for i in range(n):
        m.append(1)
    for i in range(1,n):
        for j in range(n):
            if j==0:
                m[j]=1
            else:
                m[j]=m[j-1]+m[j]
    return m[n-1]