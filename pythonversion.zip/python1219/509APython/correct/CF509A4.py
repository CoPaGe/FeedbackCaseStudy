def fun(n):
    an = ""

    z=[[1]*n for i in xrange(n)]
    for i in xrange(1,n):
        for j in xrange(1,n):
            z[i][j]=z[i-1][j]+z[i][j-1]
    return(str(z[n-1][n-1]))