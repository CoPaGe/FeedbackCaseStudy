def fun(n):
    k = [[1]*n]*n
    for i in range(1,n):
        for j in range(1,n):
            k[i][j] = k[i-1][j]+k[i][j-1]
    return k[-1][-1]