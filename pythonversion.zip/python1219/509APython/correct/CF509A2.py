def fun(n):
    matrix = [[1]*n for i in range(n)]
    if n>1:
        x =1
        maxx =0
        while x in range(n):
            y =1
            while y in range(n):
                m = matrix[x-1][y]+matrix[x][y-1]
                matrix[x][y]=m
                if m>maxx:
                    maxx=m
                y+=1
            x+=1
        return maxx
    else:
        return '1'