def fun(n):
    k = 1
    i=1
    count  = 1
    height = 0
    while(count<=n):
        height += 1
        i += 1
        k += i
        count += k
    return height