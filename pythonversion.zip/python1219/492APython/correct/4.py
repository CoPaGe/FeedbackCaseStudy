def fun(a):
    a = int(a)
 
    sum=0
    i=0
    while sum<=a:
        i=i+1
        s=(i*(i+1))/2
        sum=sum+s
    return i-1