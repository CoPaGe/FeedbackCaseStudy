def fun(n):
    ht = boxes = prev = 0
    while n > boxes:
        ht += 1
        this = prev + ht
        boxes += this
        prev = this
        if n < boxes:
            ht -= 1
    return ht