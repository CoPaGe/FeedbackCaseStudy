def fun(a):
    le=0
    cu=0
    m=1
    while cu<=a:
        le+=m
        cu+=le
        m+=1
    return m-2