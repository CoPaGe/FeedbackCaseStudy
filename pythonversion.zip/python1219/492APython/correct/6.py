def fun(n):
    cnt = 0
    i = 0
    s = 0
    
    while cnt <= n:
        i += 1
        s = i*(i+1)/2
        cnt += s
    return(i-1)