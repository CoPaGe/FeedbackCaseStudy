def fun(x):
    ans=0
    t=1
    while(x > 0):
        ans+=t
        t+=1
        x-=t+ans
    return t-1