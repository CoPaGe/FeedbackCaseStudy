def fun(i):
    t=0
    sumi=0
    l=0
    res = ""
    while(i>=0):
        res = res + str(i) +" "+str(l)+" "+str(t)
        l=l+1
        t=t+l
        i=i-t
    return res+str(l-1)
