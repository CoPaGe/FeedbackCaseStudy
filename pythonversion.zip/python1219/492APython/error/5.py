def fun(n):
    h = 1
    i = 1
    if i < 1:
        return -1
    elif n == 1:
        return 1
    while i < n:
        h += 1
        i += (h - 1) + h
    return h-1
 