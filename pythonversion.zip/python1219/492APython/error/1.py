def fun(n):
    p = 0
    if n ==1:
        return n
    else:
        for i in range(1,n):
            p = p+i
            if n < i*(i+1)/2:
                return i-1
            else:
                n = n-p