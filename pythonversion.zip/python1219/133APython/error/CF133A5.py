def fun(a):

    a=a.upper()
    count=0
    for i in range(len(a)):
        if a[i]=="H" or a[i]=="Q" or a[i]=="9":
            count=1
    if count==0:
        return "NO"
    else:
        return "YES"