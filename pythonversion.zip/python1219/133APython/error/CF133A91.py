def fun(s):
    d=['H','Q','9','+']
    l=len(s)
    flag=0
    for i in range(l):
        if s[i] in d:
            flag=1
            break
    if flag==1:
        return 'YES'
    else:
        return 'NO'