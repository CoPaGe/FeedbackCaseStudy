def fun(inp):

    sum =0
    lis = ['H','Q','9','+']
    for i in inp:
        if i in lis:
            return "YES"
           
        else :
            sum +=1
    if sum == len(inp):
        return "NO"