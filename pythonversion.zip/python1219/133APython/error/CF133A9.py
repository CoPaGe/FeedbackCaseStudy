def fun(line):
    print_chars=["H","Q","9","+"]
 
    flag=0
 
    for c in line:
        if c in print_chars:
            return "YES"            
 
    if flag==0:
        return "NO"