def fun(s):
    b = ['H','Q','9','+']
    flag = False
    for x in range(len(b)):
        if b[x] in s:
            g = True;
    if flag==True:
        return "YES"
    else:
        return "NO"
 