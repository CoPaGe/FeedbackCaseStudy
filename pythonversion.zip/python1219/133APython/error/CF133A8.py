def fun(x):
    l=[]
    res = ""
    for i in range(len(x)):
        l.append(x[i])
    if '+' in l:
        res+= "NO"
    if 'H' in l or 'Q'in l  or '9' in l:
        res+= "YES"
    else:
        res+= "NO"
    return res