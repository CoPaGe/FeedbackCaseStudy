def fun(s):
    if s.count('H') + s.count('Q') + s.count('9') > 0:
        return("YES!")
    else:
        return("NO")