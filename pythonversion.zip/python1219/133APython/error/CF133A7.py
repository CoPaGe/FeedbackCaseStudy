def fun(p):

    count=0
    for i in range(0,len(p)):
        if (p[i]=="H" or p[i]=="Q" or p[i]=="9" or p[i]=="+"):
            count+=1
            break
    if count!=0:
        return("YES")
    else:
        return("NO")