def fun(s):
    flag=0
    for i in s:
        if(i=='H' or i=='Q' or i=='9' or i=='+'):
            flag=1
    if(flag==1):
        return("YES")
    else:
        return("NO")