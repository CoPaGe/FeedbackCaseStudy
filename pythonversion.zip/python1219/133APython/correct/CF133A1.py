def fun(string):
    if ('H' in string):
        return "YES"
    elif ('Q' in string):
        return "YES"
    elif ('9' in string):
        return "YES"
    else:
        return "NO"