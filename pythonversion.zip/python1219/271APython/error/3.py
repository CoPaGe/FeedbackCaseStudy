def fun(n):
    k=1
    for i in range(n+1,9001):
        z=i
        x=z
        z1=z%10
        z=z/10
        z2=z%10
        z=z/10
        z3=z%10
        z=z/10
        z4=z%10
        
        if z1!=z2 and z2!=z3 and z3!=z4 and z1!=z4 and z1!=z3 and z2!=z4:
            return x