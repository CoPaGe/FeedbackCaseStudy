def fun(year):
    for i in range(year + 1, 9000):

        count = 0
        for i in str(i):
            for x in str(i):
                if i == x:
                    count += 1

        count3 = count
        if count3 == 4:
            return(i)

