def fun(n):
    for i in range(n+1,9001):
        if(len(str(i))==len(set(str(i)))):
            return (int(i))