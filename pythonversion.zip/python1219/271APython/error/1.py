def fun(n):
    for i in range(n+1,9001) :
        b=list(str(i))
        if len(set(b))==4 :
            return i