def fun(year):
    while(True):
        year=year+1
        b=set(str(year))
        if(len(b)==len(str(year))):
            return year