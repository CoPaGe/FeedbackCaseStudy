def fun(n):
    year=n+1
    s=str(year)
    r=set(s)
    mark=1
    while(mark):
        if(len(r)==4):
            mark=0
        else:
            year=year+1
            s=str(year)
            r=set(s)
    return year