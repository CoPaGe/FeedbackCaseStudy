def fun(n):
    for x in range(n+1,9013):
        k=str(x)
        se=set(k)
        if len(se)==4:
            return k