def fun(a):
    while 1==1:
        a+=1
        t=a//1000
        h=(a//100)%10
        s=(a//10)%10
        g=a%10
        if t!=h and t!=s and t!=g and h!=s and h!=g and s!=g:
            return a