def fun(w):
    if(w%2==0 and w<=100 and w>=1 and w!=2):
        return('YES')
    elif(w==2):
        x=w/2+1
        return('YES')
    else:
        return('NO')