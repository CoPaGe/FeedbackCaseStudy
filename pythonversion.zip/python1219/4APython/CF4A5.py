def fun(a):
    if a%2 == 0:
        return "YES"
    else:
        return "NO"