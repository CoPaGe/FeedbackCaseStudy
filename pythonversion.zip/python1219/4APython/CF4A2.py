def fun(w):
    return  "NO" if int(w)>2 or int(w)%2!=0 else "YES"
 