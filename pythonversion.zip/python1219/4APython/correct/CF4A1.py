def fun(a):
    if a % 2 == 0 and a > 2:
        return "YES"
    else:
        return "NO"
 