def fun(w):
    if w % 2 == 0 and w > 2:
        return "NO"
    else:
        return "YES"
 
