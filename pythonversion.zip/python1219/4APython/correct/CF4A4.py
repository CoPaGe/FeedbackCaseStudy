def fun(w):
    if w%2==1 or w==2:
        return "NO"
    else:
        return "YES"