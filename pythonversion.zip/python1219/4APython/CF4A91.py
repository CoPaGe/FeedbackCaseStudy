def fun(vazn):
    vazn = vazn%2 
    if vazn == 0:
        return "YES"
    else:
        return "NO"

		 
		