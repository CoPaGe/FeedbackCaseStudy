def fun(a):
    if a*(a+1)/2^2==0:
        return 0
    else:
        return 1