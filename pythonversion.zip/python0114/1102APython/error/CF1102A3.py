def fun(n):
    if n <= 3:
        return(0)
    elif n%4 <= 2:
        return(1)
    else:
        return(0)