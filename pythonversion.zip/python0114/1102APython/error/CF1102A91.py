def fun(n):
    sumA = 0
    sumB = 0
    setA = []
    setB = []
    
    for i in range(n, 0, -1):
        if (sumA > sumB):
            setB.append(i)
            sumB = sumB + i
        else:
            setA.append(i)
            sumA = sumA + i
    
    res=""

    res+=str(setA)
    res+=str(setB)
    res+=str(sumA+sumB)
    res+=str(abs(sumA - sumB))
    return res