def fun(n):
    return [1,0][(n%4) * ((n+1)% 4) == 0]