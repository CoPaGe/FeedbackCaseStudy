def fun(n):
    if((n%2)==0):
        if((n/2)%2==0):
            return "0"
        else:
            return "1"
    else:
        if((n/2)%2!=0):
            return "0"
        else:
            return "1"