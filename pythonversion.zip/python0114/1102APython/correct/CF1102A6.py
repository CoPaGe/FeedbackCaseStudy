def fun(n):
    r=n%4
    if(r==2):
        r=1
    else:
        if(r==3):
            r=0
    return r