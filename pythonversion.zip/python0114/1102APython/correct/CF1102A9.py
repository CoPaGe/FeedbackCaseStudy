def fun(n):
    return 1 if (n*(n+1)/2)%2 else 0