def fun(n):
    if n%2!=0:
        n = n+1
    if n%4==0:
        return 0
    else:
        return 1