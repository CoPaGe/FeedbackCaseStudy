def fun(N):
    if(N % 4==0):
        return "0"
    elif(N%4==1):
        return "1"
    elif(N%4==2):
        return "1"
    else:
        return "0"
 