def fun(variable):
    variable = variable % 4
    if variable == 0 or variable == 3:
        return(0)
    else:
        return(1)