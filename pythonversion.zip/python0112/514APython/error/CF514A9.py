def fun(x):
    for i in xrange(len(x)):
        saida = ""
        for char in xrange(len(x)):
            if char != i:
                saida += x[char]
            else:
                saida += str(9 - int(x[char]))
        if int(x) > int(saida):
            x = saida
    
    return x