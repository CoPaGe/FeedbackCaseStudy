def fun(x):
    resposta = ''
 
 
    for i in x:
        if int(i) > 4:
            i = str(9 - int(i))
        if resposta == '':
            resposta += '9'
        else:    
            resposta += i
    
    return resposta