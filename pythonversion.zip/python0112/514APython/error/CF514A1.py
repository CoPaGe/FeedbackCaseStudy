def fun(num):
    result = ""
    
    if num[0] == '9': result += num[0]
    for i in xrange(1, len(num), 1):
    if ((9 - int(num[i])) < int(num[i])): result += str(9 - int(num[i]))
    else: result += num[i]
    
    return result