def fun(n):
    a = map(int,n)
 
    x = len(a)
    s = ''
    for i in a:
    
        if (9 - i) < i and (9 - i) != 0:
            s = s + str(9 - i)
        else:
            s = s + str(i)
    
    return s