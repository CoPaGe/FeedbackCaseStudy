def fun(x):
    
    new_num=''
    
    for i in x:
        #return new_num
        if int(i)<5:
            new_num+=i
        else:
            new_num+=str(9-int(i))
    
    if int(x)<=9:
        new_num=x
    
    return new_num