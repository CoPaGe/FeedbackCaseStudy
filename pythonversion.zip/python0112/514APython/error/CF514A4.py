def fun(s):
    s=raw_input()
    s1=""
    for i in range(len(s)):
            if 9-int(s[i])<int(s[i]):
                            if 9-int(s[i])==0:
                                    continue
                            s1+=str(9-int(s[i]))
            else:
                                    s1+=s[i]
    if s=="9":
            return 9
    else:
            return s1
                                  
                                                                                 



        
        
 