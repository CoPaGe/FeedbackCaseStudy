def fun(n):
    output = ""
    for i in n:
        if ((9-int(i)) < int(i)) and 9-int(i) > 0:
            output+=str(9-int(i))
        else:
            output+=i
    return output