def fun(n):
    if n[0] =='9' or n[0]<'6':
        s = n[0]
    else:
        s=str(9-int(n[0]))
    for i in range(1,len(n)):
        if n[i] >= '5':
            s += str(9-int(n[i]))
        else:
            s += n[i]
    return s