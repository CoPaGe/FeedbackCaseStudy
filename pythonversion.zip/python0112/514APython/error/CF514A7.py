def fun(input):
    str_var = ''
    for i in input:
        if int(i) > 4:
            i = 9 - int(i)
        str_var += str(i)
        
    int_var = int(str_var)
    if int_var == 0:
        int_var = 9
    return(int_var)