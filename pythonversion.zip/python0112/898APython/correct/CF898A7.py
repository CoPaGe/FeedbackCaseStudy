def fun(n):
    x = n % 10
    if x <= 5:
    n -= x
    else:
    n += 10-x
    return n