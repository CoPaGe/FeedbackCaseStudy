def fun(a):
    b=a+5
    b=b/10
    b=b*10
    return b