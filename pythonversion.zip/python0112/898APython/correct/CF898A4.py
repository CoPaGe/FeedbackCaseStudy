def fun(n):
    return ((n+5)/10)*10