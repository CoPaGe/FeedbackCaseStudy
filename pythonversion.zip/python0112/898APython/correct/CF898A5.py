def fun(n):
    a = n%10
    if a==0:
        return n
    else:
        if a<=5:
            return n-a
        else:
            return n-a+10