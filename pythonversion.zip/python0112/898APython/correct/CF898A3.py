def fun(n):
    if n % 10 == 0:
        return n
    elif n % 10 <= 5:
        return (n / 10) * 10
    else:
        return (n / 10 + 1) * 10