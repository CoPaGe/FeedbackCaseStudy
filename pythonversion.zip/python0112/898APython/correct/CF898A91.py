def fun(n):
    n = str(n)
    last = n[len(n)-1]
    
    if len(n) == 1:
        after = 10
        before = 0
    else:
        after = int(str(int(n[:len(n)-1])+1) + '0')
        before = int(str(int(n[:len(n)-1])) + '0')
        
    if after - int(n) < int(n) - before:
        roundoff = after
    else:
        roundoff = before
 
    return roundoff