def fun(n):
    tail = n%10
    if tail>4:
        return n+ 10-tail
    else:
        return n-tail