def fun(a):
    return int(round(a / 10)) * 10