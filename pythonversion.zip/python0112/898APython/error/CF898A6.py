def fun(a):
    return(a-(a%10))