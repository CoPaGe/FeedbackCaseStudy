def fun(step):
    count = 1
    while(step > 5):
        count = count +1
        step = step -5
    return(step)