def fun(n):
    if n/5==0 :
        return (n)
    else:
        return (n/5)