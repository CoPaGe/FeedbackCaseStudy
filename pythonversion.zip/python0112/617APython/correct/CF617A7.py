def fun(n):
    res = n // 5 + (0 if n % 5 == 0 else 1) 
    return(res) 