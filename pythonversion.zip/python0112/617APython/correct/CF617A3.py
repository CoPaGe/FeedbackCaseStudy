def fun(entrada):
    count = 0
    
    for i in range(5,0,-1):
        count += entrada/i
        entrada -= (entrada/i)*i
    
    
    return count