def fun(n):
    count=0
    if n%5>0:
        count=count+1
    count=count+n/5
    return count