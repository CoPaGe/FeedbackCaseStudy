def fun(n):
    if n%5 == 0:
        return n/5
    else:
        return n/5+1