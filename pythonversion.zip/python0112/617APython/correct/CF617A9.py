def fun(x):
    if x %5 == 0:
        b = x//5
        return b
    else:
        a = x//5 + 1
        return a