def fun(a):
    if a%5!=0:
        return a//5+1
    else:
        return a/5