def fun(n):
    num=0
    
    if n>5:
        num=n/5
        if n%5>0 and n%5<5:
            num+=1
    else:
        num=1
    return num