def fun(x):
    c= 0
    while(x > 0):
        x -= 5
        c += 1
    return c