def fun(s):
    num = ''
    i = 0
    flag = -1
    while i < len(s)-1:
        if s[i] == '-' and s[i+1] == '-':
            num += '2'
            i += 1
            flag = -1
        elif s[i] == '-' and s[i+1] == '.':
            num += '1'
            i += 1
            flag = 1
        else:
            num += '0'
            flag = -1
        i += 1
    
    if s[len(s)-1] == '.':
        if flag == -1:
            num += '0'
    print num