def fun(ternary):
 
    acum = 0
    res = ""
    for i in xrange(len(ternary)):
        if ternary[i] == ".":
            res += str(acum)
            acum = 0
        else:
            acum += 1
    
    print res + str(acum)