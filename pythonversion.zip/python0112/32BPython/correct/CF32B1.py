def fun(text):
    ret = ""
    a = 0
    for d in text:
        if d == '.':
            if a == 0:
                ret += '0'
            elif a == 1:
                ret += '1'
                a = 0
        else:
            a = a + 1
        if a == 2:
            ret += '2'
            a = 0
    
    return ret