def fun(inp):
    i = 0
    ans = ""
    while i < len(inp):
        #print ""
        #print "i ", i
    
        if inp[i] == ".":
    
            ans += "0"
            i += 1
    
        elif inp[i] == "-":
    
            if inp[i + 1] == ".":
    
                ans += "1"
    
            elif inp[i + 1] == "-":
    
                ans += "2"
    
            i += 2
    
    
    
    print ans