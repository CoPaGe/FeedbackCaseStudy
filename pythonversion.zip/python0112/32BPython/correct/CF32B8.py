def fun(s):
    i=0
    ans=""
    while i<len(s):
        if s[i]=='.':
            ans=ans+'0'
            i=i+1
        elif s[i]=='-'and s[i+1]=='-':
            ans=ans+'2'
            i=i+2
        elif s[i]=='-' and s[i+1]=='.':
            ans=ans+'1'
            i=i+2
    
    print ans