def fun(s):
    s=s.replace('--','2') 
    s=s.replace('-.','1') 
    s=s.replace('.','0')	
    print s