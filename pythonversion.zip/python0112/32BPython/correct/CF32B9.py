def fun(s):
    i=0
    p=''
    while(i<len(s)):
        if(s[i]=='-' and s[i+1]=='.'):
            p+='1'
            i+=2
            continue
        elif(s[i]=='-' and s[i+1]=='-'):
            p+='2'
            i+=2
            continue
        elif(s[i]=='.'):
            p+='0'
            i+=1
    print p