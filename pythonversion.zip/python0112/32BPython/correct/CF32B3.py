def fun(x):
    x = raw_input()
    i=0
    ans = list()
    while i < len(x)-1:
        if x[i]=='.':
            ans.append('0')
            i+=1
        elif x[i]=='-':
            if x[i+1] == '.':
                ans.append('1')
                i+=2
            elif x[i+1] == '-':
                            ans.append('2')
                i+=2
    if i == len(x)-1 and x[i]=='.':
        ans.append('0')
    
    print ''.join(ans)