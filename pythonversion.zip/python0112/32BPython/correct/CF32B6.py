def fun(s):
    a=' '
    n=len(s)
    i=0
    while(i<=n-1):
        if(s[i]=='.'):
            a=a+'0'
            i=i+1
        elif(s[i]=='-' and s[i+1]=='.' and i+1<n):
                a=a+'1'
                i=i+2
        elif(s[i]=='-' and s[i+1]=='-' and i+1<n):
            a=a+'2'
            i=i+2
    print(a[1:])