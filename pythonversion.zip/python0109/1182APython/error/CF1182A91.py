def fun(n):
    a=int(n)
    if a%2==0:
        return a
    else:
        return 0