def fun(n):
    n = int(n)
 
    if n%2 == 0:
        return n
    
    else:
        return 0