def fun(n):
    n = int(n)
    import math
    
    if n % 2 != 0:
        return 0
    else:
        return math.pow(2, n//2)