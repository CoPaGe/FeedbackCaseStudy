def fun(n):
    n=int(n)
    if n%2==1:
        return 0
    else:
        return 2**(n/2)