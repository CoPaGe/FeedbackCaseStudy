def fun(n):
    n = int(n)
    t = []
    t.append(0)
    t.append(0)
    t.append(2)
    t.append(0)
    t.append(4)
    for i in range (5, n+1):
        t.append(2*t[i-2])
    return(t[n])