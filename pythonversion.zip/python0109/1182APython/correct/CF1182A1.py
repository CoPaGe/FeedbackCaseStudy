def fun(n):
    n=int(n)
    if n%2==0:
        return 2**(n/2)
    else: return 0