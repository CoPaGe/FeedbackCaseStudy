def fun(n):
    n=int(n)
    if n%2:
        return(0)
    else :
        return(pow(2,n/2))