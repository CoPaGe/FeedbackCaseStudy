def fun(n):
    user_input = int(n)
    
    new_name = ""
    for i in range(1, user_input + 1):
        n = i
        the_list = [1]
        count = 1
        for i in range (1, n):
            the_list.append(count)
            prev = the_list[i - 1]
            count = count + prev
        return the_list

        if i in fibonacci(user_input):
            new_name = new_name + "O"
        else:
            new_name = new_name + "o"
    
    return new_name