def fun(n):
    n=int(n)
    one=two=1
    lst=[1,1]
    s1="OO"
    for i in range(n):
        third=one+two
        one,two=two,third
        lst.append(third)
    for j in range(3,n+1):
        if j in lst:
            s1+="O"
        else:
            s1+="o"
    return s1

print(fun(1))