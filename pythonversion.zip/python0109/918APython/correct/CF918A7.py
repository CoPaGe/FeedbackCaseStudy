def fun(n):
    n = int(n.strip())
    fib = [1, 1]
    while fib[-1] < 1000:
        fib.append(fib[-1] + fib[-2])
    res = ''
    for i in range(n):
        if i + 1 in fib:
            res += 'O'
        else:
            res += 'o'
    return res
 
