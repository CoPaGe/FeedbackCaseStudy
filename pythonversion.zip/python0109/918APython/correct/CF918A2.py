def fun(n):
    i=0
    l=list()
    l.append(1)
    l.append(1)
    while(i<=1000):
        l.append(l[i]+l[i+1])
        i=i+1
    n=int(n)
    s=''
    for j in range(1,n+1,1):
        if j in l:
            s=s+'O'
        else:
            s=s+'o'
    return(s)