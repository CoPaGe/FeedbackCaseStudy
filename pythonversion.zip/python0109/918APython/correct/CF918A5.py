def fun(n):
    fib = []
    fib.append(1)
    fib.append(1)
    for i in range(2,16):
        num = fib[i-1] + fib[i-2]
        fib.append(num)
    arr = [0]*(1005)
    for i in range(0,len(fib)):
        arr[fib[i]] = 1
    n = int(n)
    ans = ""
    for i in range(0,n):
        if arr[i+1] == 1:
            ans += "O"
        else:
            ans += "o"
    return ans