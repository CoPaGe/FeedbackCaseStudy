def fun(n):
    n = int(n)
 
    fib1 = 1
    fib2 = 2
    name = "O"
    
    for i in range(2, n+1):
        if fib1 < fib2:
            if i == fib2:
                name += "O"
                fib1 += fib2
            else:
                name += "o"
        else:
            if i == fib1:
                name += "O"
                fib2 += fib1
            else:
                name += "o"
    return name