def fun(n):
    n = int(n)

    fibonacci = [1,1]
    for x in range(2,1000):
        fibonacci.append(fibonacci[x-1]+fibonacci[x-2])
    input=""
    for x in range(1,n+1):
        if x in fibonacci:
            input+="O"
        else:
            input+="o"
    return input
