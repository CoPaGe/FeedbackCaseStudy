def fun(n):
    n = int(n)
    f = [0, 1, 1]
    i = 3
    while (1):
        f.append(f[i - 1] + f[i - 2])
        if (f[i] >= n) :
            break
        i += 1
    l = 2
    for i in range (1, n + 1) :
        if (i == f[l]) :
            return 'O',
            l += 1
        else :
            return 'o',