def fun(n):
    l = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987]
    n = int(n)
    a = ''
    for i in range(1,n+1):
        if i in l:
            a += 'O'
        else:
            a += 'o'
    return a