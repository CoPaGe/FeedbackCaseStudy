def fun(n):
    import sys
    n=int(n)
    
    fib=[]
    last=1
    l=2
    fib.append(1)
    fib.append(1)
    while(last<n):
        fib.append(fib[l-1]+fib[l-2])
        l=l+1
        last=fib[l-1]
    
    result=""
    for i in range(1,n+1):
        if(i in fib):
            result+='O'
        else:
            result+='o'	