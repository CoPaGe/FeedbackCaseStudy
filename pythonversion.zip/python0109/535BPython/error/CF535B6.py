def fun(n):
    arr=[]
    trueindex=True
    for x in xrange(0,n+10):
        for y in str(x):
            if y=="4" or y=="7":
                1+1
            else:
                break
            arr.append(x)
    if n in arr: return arr.index(n)+1
