def fun(n):
 
    m = len(n)
    out = 0
    
    for e in n :
        out += m
        if e == '7' :
            out += m
        m -= 1
        
    return out
        