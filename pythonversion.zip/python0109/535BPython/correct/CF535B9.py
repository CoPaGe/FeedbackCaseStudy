def fun(n):
    import math
    
    s = ''
    
    for _ in n:
    
        if _ == '4':
            
            s += '0'
            
        if _ == '7':
            
            s += '1'
    
    return int(math.pow(2, len(s)))+int(s, 2)-1