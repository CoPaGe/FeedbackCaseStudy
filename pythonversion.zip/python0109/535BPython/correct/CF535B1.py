def fun(n):
    n = '1'+n.replace('4', '0').replace('7', '1')
    return int(n, 2) - 1