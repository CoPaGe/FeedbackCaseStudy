def fun(k):
    l=len(k)
    x=1
    result=0
    for x in range (0,l) :
        result=result + pow(2,x)
    x=0
    for x in range (0,l) :
        if int(k[x:x+1])==7 :
            result+= pow(2,l-1-x)
    return result