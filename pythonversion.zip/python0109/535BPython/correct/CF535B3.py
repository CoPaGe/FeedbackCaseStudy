def fun(s):
    n = len(s)
    x = pow(2, n) - 1
    d = 1
    for a in reversed(s):
            if a == '7': x += d
            d *= 2
    return x