def fun(n):
    G = list(n)
 
    while '4' in G:
    
        G[G.index('4')] = '0'
    
    while '7' in G:
    
        G[G.index('7')] = '1'
    
    k = ''.join(G)
    
    i = 1
    
    s = 0
    
    while i < len(G):
    
        s = s + 2**i
    
        i = i + 1
    
    s = s + int(k,2) + 1
    
    
    return s