def fun(n):
    lucky = n
    lucky = lucky.replace('4', '0')
    lucky = lucky.replace('7', '1')
    
    return int(lucky, 2) + 2**(len(lucky)) - 2 + 1