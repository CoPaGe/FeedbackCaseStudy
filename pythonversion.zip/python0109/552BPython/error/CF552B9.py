def fun(n):
    n = int(n)
    number_of_digits = 0; 
  
    for i in range(1, n, 10): 
        number_of_digits = (number_of_digits + 
                                 (n - i + 1)); 
          
    return number_of_digits+1; 