def fun(n):
    n = int(n)
 
    if n < 10:
        return n
    elif n < 100:
        return n + (n - 9)
    elif n < 1000:
        return n + (n - 99)
    elif n < 10000:
        return n + (n - 999)
    elif n < 100000:
        return n + (n - 9999)
    elif n < 1000000:
        return n + (n - 99999)
    elif n < 10000000:
        return n + (n - 999999)
    elif n < 100000000:
        return n + (n - 9999999)
    elif n < 1000000000:
        return n + (n - 99999999)
    else:
        return n + (n - 999999999)