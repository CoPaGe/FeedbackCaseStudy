def fun(n):
    valor = n
 
    resultado = 0
    tamanho = len(valor)
    diferenca = int(valor) - (9 * (10**(tamanho-2)))
    for i in range(tamanho - 1):
        resultado += 9 * (10**i)
    resultado += diferenca * tamanho
    if tamanho > 1:
        return resultado
    else:
        return valor
