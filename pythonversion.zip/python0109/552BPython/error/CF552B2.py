def fun(n):
    n=int(n)
    

    digs=0
    while n!=0:
        digs += 1
        n=n/10
    ndigs=digs
    nd=ndigs
    
    if n%10==0:
        nd -= 1
    total_digs=int((9*(10**(nd-2))) + (n - (9*(10**(nd-2))))*nd)
    
    if n%10==0:
        total_digs += 1
    
    return total_digs