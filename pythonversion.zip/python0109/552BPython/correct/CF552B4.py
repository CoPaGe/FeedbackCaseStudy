def fun(n):
    num = int(n)
    
    cont1 = num
    
    if num > 9 :
        cont1 += num - 9
    if num > 99 :
        cont1 += num - 99	
    if num > 999 :
        cont1 += num - 999
    if num > 9999 :
        cont1 += num - 9999
    if num > 99999 :
        cont1 += num - 99999
    if num > 999999 :
        cont1 += num - 999999
    if num > 9999999 :
        cont1 += num - 9999999
    if num > 99999999 :
        cont1 += num - 99999999
    if num > 999999999 :
        cont1 += num - 999999999
    
    return cont1