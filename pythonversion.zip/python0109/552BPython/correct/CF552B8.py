def fun(n):
    d = int(n)
    output  = 0
    cont = 9
    
    while (d > 0):
        output+=d
        d-= cont
        cont*=10
    return(output)