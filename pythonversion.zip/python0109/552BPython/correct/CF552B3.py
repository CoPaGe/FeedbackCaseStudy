def fun(n):
    n = int(n)
    ans = 0
    for l in range(1, 11):
        if (l == len(str(n))):
            ans += (n - 10**(l-1) + 1) * l
        elif (l < len(str(n))):
            ans += (9 * 10**(l - 1)) * l
        else:
            break
    
    return ans