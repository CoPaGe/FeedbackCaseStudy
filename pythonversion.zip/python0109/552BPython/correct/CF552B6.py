def fun(n):
    n = int(n)
    p = 10
    ans = 0
    for i in range(1, 20):
        if i == len(str(n)):
            ans += (n + 1 - 10**(i-1))*i
        elif i < len(str(n)):
            ans += 9*(10**(i-1))*i
    return ans