def fun(n):
    n = int(n)
    i = 9
    d = 0
    while(n > 0):
        d += n
        n -= i
        i *= 10
    
    return d