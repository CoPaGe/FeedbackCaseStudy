def fun(n):
    word = n
    flag = 0
    length = len(word)/2
    
    for i in range(length):
        if word[i] != word[len(word)-1-i]:
            flag += 1
    
    if ((flag == 1) | ((flag==0) & (len(word)%2 == 1))):
        return("YES")
    
    else:
        return ("NO")