def fun(n):
    line=n
    n=len(line)
    
    if n==1:
        return "YES"
        exit()
    pal = True
    count = 1
    
    for i in range(n/2):
        if line[i] != line[n-i-1]:
            if count>0:
                count=count-1
            else:
                pal=False
                break
    if n%2==1 and count==1:
        count=count-1
    
    if pal==True and count==0:
        return "YES"
    else:
        return "NO"