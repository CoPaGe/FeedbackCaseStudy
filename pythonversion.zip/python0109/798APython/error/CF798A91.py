def fun(n):
    string = n
    miscount = 0
    ind = 0
    cnt = 0
    leng = len(string)
    for i in range(leng/2):
        if string[i] == string[leng - 1-i]:
            cnt = cnt + 1
    count = leng/2
    if count == cnt:
        if leng%2 != 0:
            return('YES')
        else:
            return('NO')
    else:
        if (count-1) == cnt and leng == 3:
            return('NO')
        else:
            if (count-1) == cnt:
                return('YES')
            else:
                return('NO')    