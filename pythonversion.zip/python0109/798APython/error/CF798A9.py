def fun(n):
    s=n
    k=len(s)
    c=0
    for i in range(k/2):
        if s[i]!=s[k-i-1]:
            c=c+1
    if c==1:
        return "YES"
    else:
        return "NO"