def fun(n):
    s = n
    m, i, j = 0, 0, len(s) - 1
    while i < j:
            if s[i] != s[j]: m += 1
            i += 1
            j -= 1
    if m == 1: return 'YES'
    else: return 'NO'