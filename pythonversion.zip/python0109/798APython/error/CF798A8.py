def fun(n):
    line=n
    n=len(line)
    
    if n%2==0:
        j=n-1
        k=0
        for i in range(n/2):
            if line[i]!=line[j]:
                k+=1
            j=j-1
    
        if k==1:
            return "YES"
            exit()
        else:
            return "NO"
            exit()
    else:
        j=n-1
        k=0
        for i in range(n/2):
            j=j-1
            if line[i]!=line[j]:
                k+=1
            if k<=1:
                return "YES"
                exit()
            else:
                return "NO"
                exit()