def fun(n):
    s1=n
    s2=s1[::-1]
    cnt=0
    for i in range(len(s1)):
        if s1[i]<>s2[i]:
            cnt+=1
    if cnt==2 or cnt==0:
        return 'YES'
    else:
        return 'NO'
        