def fun(n):
    x=n
    l=0
    c=0
    r=len(x)-1
    while(l<=r):
        if(x[l]!=x[r]):
            c+=1
        l+=1
        r-=1
    if c==1:
        return "YES"
    else:
        return "NO"