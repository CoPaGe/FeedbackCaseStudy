def fun(n):
    x = n
 
    count = 0
    
    for i in range((len(x) +1) / 2):
        if x[i] != x[len(x) - 1 - i]:
            count += 1
    
    if count == 1:
        return "YES"
    else:
        return "NO"