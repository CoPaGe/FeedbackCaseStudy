def fun(n):
    s = n.strip()
    c = 0
    for i in range(len(s)/2):
        if s[i] != s[-1 - i]: c += 1
    if c > 1: return "NO"
    else: return "YES"