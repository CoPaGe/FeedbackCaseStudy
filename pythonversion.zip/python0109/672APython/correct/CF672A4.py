def fun(n):
    palavra = ""
    num = 1
    while len(palavra) < 1010:
        palavra += str(num)
        num += 1
    
    n = int(n)) - 1
    return palavra[n]