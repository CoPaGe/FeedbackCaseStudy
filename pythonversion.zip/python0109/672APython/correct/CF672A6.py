def fun(n):
    s = ''
    for i in range(388):
        s += str(i)
    return s[int(n)]