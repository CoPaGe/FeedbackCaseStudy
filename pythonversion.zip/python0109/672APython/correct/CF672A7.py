def fun(n):
    a="123456789"
    n=int(n)
    for i in range(10,372):
    a=a+str(i)
    return(a[n-1])