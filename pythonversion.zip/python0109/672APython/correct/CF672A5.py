def fun(n):
    n = int(n)
    s= ""
    for x in range(1,n+1):
        s+=str(x)
    
    return s[n-1]  