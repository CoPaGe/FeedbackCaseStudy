def fun(n):
    l = ""
    for x in range(1000):
    if len(l) > 1010:
    break
    l += str(x)
    
    return l[int(n)]