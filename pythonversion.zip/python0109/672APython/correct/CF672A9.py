def fun(n):
    n = int(n)
    input = "123456789101112131415"
    for x in range(16,1000):
        input+=str(x)
    return input[n-1]