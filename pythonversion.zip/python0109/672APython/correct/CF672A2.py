def fun(n):
    n = int(n)
    s = ""
    for i in range(1,n+1):
        s += str(i)
    return s[n-1]