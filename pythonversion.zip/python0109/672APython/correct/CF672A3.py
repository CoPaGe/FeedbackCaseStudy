def fun(n):
    n= int(n)
    s = ""
    for i in xrange(1,1001):
            s+= str(i)
    return s[n-1]