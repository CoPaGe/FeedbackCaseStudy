def fun(n):
    n = int(n)
 
    s = ""
    for i in range(1,370):
        s += str(i)
        
    s += "3"
    
    return s[n-1]