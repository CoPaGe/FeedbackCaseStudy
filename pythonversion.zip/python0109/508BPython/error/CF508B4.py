def fun(s):
    l = len(s)
    k = int(s[-1])
    even, n, b, p = '02468', 0, -1, -1
    for i in xrange(l):
        if s[i] in even:
            p = i
            if int(s[i]) > k and b != -1:
                b = i
    
    if p == -1:
        return -1
    else:
        if b != -1: p = b
        ans = s[:p] + s[-1] + s[p + 1:l - 1]  + s[p]
        return ans