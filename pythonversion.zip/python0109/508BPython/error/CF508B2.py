def fun(x):
    y=int(x)
    base=int(x[-1])
    flag=0
    ma=[""]
    for g in xrange(len(x)-1):
        if (int(x[g])%2==0):
            d=(x[:g]+str(base)+x[g+1:-1]+x[g])
            if base>int(x[g]):
                ma[0]=d
                flag=1
                break
    if (flag==0):
        for g in xrange(len(x)-1):
            if (int(x[len(x)-g-2])%2==0):
                d=(x[:len(x)-g-2]+str(base)+x[len(x)-g-1:-1]+x[len(x)-g-2])
                if int(x[g])>base:
                    ma[0]=d
                    flag=1
                    break
    
    if (flag==0):
        return -1
    else:
        return ma[0]