def fun(n):
    n = str(n)
    end = int(n[len(n)-1])
    index = 0
    for x in range(0,len(n)):
        if int(n[x])%2==0:
            if end>int(n[x]):
                return n[0:x]+n[len(n)-1]+n[x+1:len(n)-1]+n[x]
            else:
                index = x
    return n[0:index]+n[len(n)-1]+n[index+1:len(n)-1]+n[index]