def fun(s):
    n = len(s)
    if ( int(s[n-1]) %2 == 1 ):
        min = 10
        for i in range(n-1):
            if int(s[i])%2 == 0 and int(s[i]) < min : 
                min = int(s[i])
                
        
    
    if min == 10 : return -1
    elif min < int(s[n-1]) :
        k = s.find(str(min))
        return s[:k]+s[n-1]+s[k+1:n-1]+str(min)
    else:	
        k = s.rfind(str(min))
        return s[:k]+s[n-1]+s[k+1:n-1]+str(min)