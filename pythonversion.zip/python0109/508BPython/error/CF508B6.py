def fun(n):
 
    max_even_i = None
    for i in range(len(n)):
    
        if int(n[i]) % 2 == 0:
            max_even_i = i
    
    if max_even_i != None:
        return n[:max_even_i] + n[len(n)-1] + n[max_even_i + 1: -1] + n[max_even_i]
    else:
        return - 1