def fun(L):
    L=list(L);n=len(L);f=0
    for i in range(n):
        if int(L[i])<int(L[n-1]) and int(L[i])%2==0 and f==0:
            f+=1
            temp=L[i];L[i]=L[n-1];L[n-1]=temp
            return ''.join(L)
    for i in range(n-2,-1,-1):
        if int(L[i])%2==0 and f==0:
            f+=1
            temp=L[i];L[i]=L[n-1];L[n-1]=temp
            return ''.join(L)
    if f==0:
        return -1