def fun(s):
    s = list(s)
    t = -1
    for i in xrange(len(s) - 1):
        if int(s[i]) % 2 == 0 :
            t = i
            if s[i] <= s[-1] : break
    if t == -1 : return -1
    else :
        s[t], s[-1] = s[-1], s[t]
        return ''.join(s)