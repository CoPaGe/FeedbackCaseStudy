def fun(a):
    n = len(a)
    if int(a[-1])%2==0:
        b = 0
        c = 0
        for i in xrange(n):
            if int(a[i])>=b:
                c = i
                b = a[i]
        d = 0
        for i in xrange(n):
            if int(a[i])<b:
                d = i
                break
        return a[0:d]+a[c]+a[d+1:c]+a[d]+a[c+1:]
    else:
        b1 = 10
        c1 = -1
        b2 = -2
        c2 = -1
        for i in xrange(n):
            d = int(a[i])
            e = int(a[-1])
            #return d,e
            if d%2==0 and d>e:
                c1=i
            if d%2==0 and d<e:
                if c2 == -1:
                    c2 = i
        if c1==-1 and c2==-1:
            return -1
        elif  c2<>-1:
            return a[:c2]+a[-1]+a[c2+1:-1]+a[c2]
        else:
            return a[:c1]+a[-1]+a[c1+1:-1]+a[c1]