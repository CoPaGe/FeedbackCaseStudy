def fun(s):
    y = int(s[-1])
    j = -1
    for i in range(len(s)):
            x = int(s[i])
            if x % 2 == 0:
                    j = i
                    if x < y:
                            break
    if j == -1:
            return -1
    else:
            q = ''
            for i in range(len(s)):
                    if i == len(s)-1:
                            q += s[j]
                    elif i == j:
                            q += s[-1]
                    else:
                            q += s[i]
            return q