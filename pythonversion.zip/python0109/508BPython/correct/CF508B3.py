def fun(n):
    l=len(n)
    d=n[l-1]
    flag=0
    for i in xrange(l):
        x=int(n[i])
        if(x%2==0 and x<int(d)):
            n=list(n)
            n[l-1]=n[i]
            n[i]=d
            n=''.join(n)
            
            flag=1
            break
        elif(x%2==0):
            pos=i
            flag=2    
    if(flag==0):
        return "-1"
    elif(flag==1):
        return n
    else:
        n=list(n)
        n[l-1]=n[pos]
        n[pos]=d
        n=''.join(n)
        return n