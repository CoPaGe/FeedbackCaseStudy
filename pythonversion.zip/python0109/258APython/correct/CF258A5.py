def fun(s):
    r = 0
    if '0' in s:
        r = s.index('0')
    
    return s[:r] + s[r + 1:]