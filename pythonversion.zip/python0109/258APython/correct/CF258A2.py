def fun(s):
    try:
        i=s.index('0')
        return s[:i]+s[i+1:]
    except:
        return s[:-1]