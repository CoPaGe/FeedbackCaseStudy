def fun(s):
    x=s.find("0")
    if x==-1:
        return s[:-1]
    else:
        r=""
        for i in xrange(len(s)):
            if i==x:
                pass
            else:
                r+=s[i]
        return r