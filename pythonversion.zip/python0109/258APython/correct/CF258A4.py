def fun(a):
    b = -1
    for i in xrange(len(a)):
        if a[i]=='0':
            b=i
            break
    return a[:b]+a[b+1:] if b>=0 else a[:-1]