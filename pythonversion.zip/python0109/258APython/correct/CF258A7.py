def fun(number):
 
    new_num=''
    
    j=len(number)-1
    
    while number[j]!='0' and j>=0:
        j-=1
    
    if j<0:
        new_num=number[:len(number)-1]
    else:
        new_num=number[:j]+number[j+1:]
    
    return new_num