def fun(s):
    if '0' in s:
        return s.replace('0', '', 1)
    else:
        return s[1:]