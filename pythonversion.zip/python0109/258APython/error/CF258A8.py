def fun(s):
    ans=""
    flag=0
    for i in range(0,len(s)):
        if flag==0:
            if s[i]=='0':            
                flag=1
            else:
                ans=ans+s[i]
        else:
            ans=ans+s[i]
    
    return ans