def fun(a):

    a = str(a)[::-1]

    lastzero = a.rfind("0")
    return (a[0:lastzero]+ a[lastzero+1:])[::-1]