def fun(s):
 
    flag = 0
    
    a = ""
    
    for i in s:
    
        if flag or i == '1':
    
            a += i
    
        if i == '0':
    
            flag = 1
    
    return a