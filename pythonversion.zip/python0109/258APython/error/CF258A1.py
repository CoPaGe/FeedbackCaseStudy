def fun(s):
    s = list(s)
    for i in range(len(s)):
        if s[i] == '0':
            s.pop(i)
            break
    a = ""
    for i in range(len(s)):
        a += s[i]
    return a