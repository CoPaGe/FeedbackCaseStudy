def fun():
    ch = n
    maxc = 0
    compt = 0
    for i in range(len(ch)):
        compt += 1
        if ch[i] in ['A', 'E', 'I', 'O', 'U', 'Y']:
            if compt >maxc:
                maxc = compt
            compt = 0
    if (compt== len(ch)):
        return len(ch)+1
    else:
        print min(maxc, compt+1)