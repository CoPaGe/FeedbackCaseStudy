def fun(n):
    letters = n
    temp = 0
    temp2 = 0
    
    for i in letters:
        if len(letters) == 1 and i not in "AEIOUY":
            temp2 = 1
            break
        if i not in "AEIOUY":
            temp += 1
        else:
            if temp > temp2:
                temp2 = temp
                temp = 0
    temp2 += 1
    return(temp2)