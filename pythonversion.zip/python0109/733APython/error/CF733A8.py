def fun(n):
    s = n
 
    vowels = {'A', 'E', 'I', 'O', 'U','Y'}
    
    last = 0
    out = [1]
    for i in range(len(s)):
        if (s[i] in vowels):
            out.append(i - last)      
            last = i
    return max(out)