def fun(n):
    s=n
 
    vowels='AEIOUY'
    jumps=[]
    jump=0
    
    for i in s:
        if i in vowels:
        jump+=1
        else:
            jumps.append(jump)
            jump=0
    
    if len(jumps)==0:
        return 1
    else:
        return max(jumps)+1