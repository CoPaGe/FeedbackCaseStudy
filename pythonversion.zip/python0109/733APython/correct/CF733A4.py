def fun(n):
    L,N,K=list(n),[0],[]
    for i in range(len(L)):
        if L[i]=='A' or L[i]=='E' or L[i]=='I' or L[i]=='O' or L[i]=='U' or L[i]=='Y':
            N.append(i+1)
    N.append(len(L)+1)
    for i in range(len(N)-1):
        K.append(N[i+1]-N[i])
    return max(K)