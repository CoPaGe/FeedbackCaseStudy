def fun(n):
    s = n
    s = " "+ s +"-"
    
    last_vowel = 0
    result = 0
    
    for i in range(len(s)):
        if s[i] in ['A', 'E', 'I', 'O', 'U', 'Y', "-"]:
            length = i - last_vowel
            last_vowel = i
            if result < length:
                result = length
    
    return result