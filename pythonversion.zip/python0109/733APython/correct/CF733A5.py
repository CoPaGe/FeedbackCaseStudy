def fun(n):
    s=n
    j=1
    l=[0]
    for i in range(0,len(s)):
        if s[i]=='A' or s[i]=='E' or s[i]=='I' or s[i]=='O' or s[i]=='U' or s[i]=='Y' :
            j=1
            l.append(j)
        else :
            j=j+1
            l.append(j)
    l.sort()
    return(l[-1])