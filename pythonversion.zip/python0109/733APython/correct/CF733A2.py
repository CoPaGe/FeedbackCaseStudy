def fun(n):
    s=n
    s='A'+s+'A'
    mini=-1
    a=[]
    t=0
    for i in range(1,len(s)):
        if s[i] in 'AEIOUY':
            mini=max(mini,i-t)
            t=i
    return mini