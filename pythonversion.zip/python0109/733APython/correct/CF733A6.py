def fun(n):
    str=n
    max=0
    count=0
    noOfVowels=0
    for i in range(0,len(str)):
        if (str[i]=='A' or str[i]=='E' or str[i]=='I' or str[i]=='O' or
        str[i]=='U' or str[i]=='Y'):
            count+=1
            noOfVowels+=1
            if (count>max):
                max=count
            count=0
        if (str[i]!='A' and str[i]!='E' and str[i]!='I' and str[i]!='O' and str[i]!='U' and str[i]!='Y'):
            count+=1
            if (i==len(str)-1 and count>=max):
                count+=1
                max=count
                
    if noOfVowels==0:
        return len(str)+1
    else:
        return max