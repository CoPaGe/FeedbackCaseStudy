def fun(n):
    s = n
    s = 'A' + s + 'A'
    z=0
    l=0
    for i in s:
        if i in 'AEIOUY':
            l=1
        else:
            l = l+1
        z = max(z,l)
    return z