def fun(n):
    n = int(n)

    if n%2!=0:
        return 0
    nhalf=n/2
    if nhalf%2==0:
        return (nhalf/2)-1
    else:
        return (nhalf-1)/2
 
