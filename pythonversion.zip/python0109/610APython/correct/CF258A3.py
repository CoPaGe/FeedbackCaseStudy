def fun(n):
    num = int(n)
    
    if num % 2 == 0:
        
        metade = (num / 2) - 1
        
        return (metade / 2)
    
    else:
        
        return 0
 
