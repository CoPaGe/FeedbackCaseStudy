def fun(n):
    n=int(n)
    return 0 if n%2 else (n-1)/4
 
