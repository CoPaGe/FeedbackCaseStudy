def fun(n):
    n=int(n)
    
    if n%2!=0:
        return 0
    else:
        return (n-1)/4
 
