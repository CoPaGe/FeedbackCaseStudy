def fun(n):
    n = int(n)
 
    if n % 2 != 0: 
        return 0
    else:
        if n % 4 == 0: return (n / 4) - 1
        else: return n / 4
 
