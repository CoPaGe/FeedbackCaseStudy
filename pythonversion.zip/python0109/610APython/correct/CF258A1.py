def fun(n):
    n = int(n)
    
    if n%2 != 0:
        return 0
    elif n%4 != 0:
        return n/4
    else:
        return (n/4)-1
 
