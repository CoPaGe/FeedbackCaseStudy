def fun(n):
    a = int(n)
 
    a /=2
    
    if a %2 == 0:
        return (max(a/2 -1, 0))
    else:
        return (a/2)
 
