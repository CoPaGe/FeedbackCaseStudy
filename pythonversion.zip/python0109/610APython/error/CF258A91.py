def fun(n):
    comprimento = int(n)
 
    if comprimento % 4 == 0:
        return (comprimento/4) -1
    else:
        return comprimento/4