def fun(n):
    entrada = int(n))
    
    if entrada % 4 == 0:
        
        saida = entrada/4 -1
        
        
    else:
        
        saida = entrada/4
        
        
    return saida
 
