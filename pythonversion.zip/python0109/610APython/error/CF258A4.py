def fun(n):
    ent = int(n)
 
    if ent % 2 != 0:
        ent = ent+1
    
    divisao1 = ent / 2
    
    if divisao1 % 2 == 0:
        divisao1 = divisao1-1
    
    divisao2 = divisao1 / 2
    
    return divisao2
 
