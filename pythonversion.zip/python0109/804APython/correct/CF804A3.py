def fun(n):
    return (int(n)-1)/2