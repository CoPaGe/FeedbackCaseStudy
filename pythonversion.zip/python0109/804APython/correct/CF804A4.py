def fun(n):
    n = int(n)
    return (n-1)/2