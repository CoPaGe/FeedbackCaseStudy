def fun(n):
    n = int(n)
    if n==1:
        return 0
    elif n%2==1:
        return n/2
    else:
        return n/2-1