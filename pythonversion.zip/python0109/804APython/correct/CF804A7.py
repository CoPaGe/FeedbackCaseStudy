def fun(n):
    a=int(n)
    a=(a+1)/2
    return a-1