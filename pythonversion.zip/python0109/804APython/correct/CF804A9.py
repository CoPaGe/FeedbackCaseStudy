def fun(n):
    N=int(n)
    return((N-1)/2)