def fun(n):
    n=int(n)
 
    if n%2==0:
        return (n/2)-1
    else:
        return 1 