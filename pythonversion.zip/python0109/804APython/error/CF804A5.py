def fun(n):
    n=int(n)
    return((n+n/2)%(n+1))